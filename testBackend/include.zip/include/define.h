#ifndef DEFINE_H
#define DEFINE_H
#include "ControlCAN.h"
#include "ECanVci.h"

#define CANDEV_CX 0
#define CANDEV_GC 1
#define IS_GKJ 1
#endif // DEFINE_H
