#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <cmath>
#include <iostream>
#include <QtSerialPort/QSerialPort>         // 提供访问串口的功能
#include <QtSerialPort/QSerialPortInfo>      // 提供系统中存在的串口信息
#include <list>

#include "IVrPickMotor.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;

private:

private slots:
    void on_btn_init_clicked();
    void on_btn_init_serial_clicked();

    void on_btn_can_send_clicked();

    void on_btn_motor_enable_clicked();
    void on_btn_motor_disable_clicked();

    void on_btn_motor_run_clicked();
    void on_btn_motor_run_zero_clicked();
    void on_btn_motor_foreward_clicked();
    void on_btn_motor_reversal_clicked();

    void on_btn_motor_stop_clicked();
    void on_btn_motor_zero_clicked();

    void on_btn_motor_readangle_clicked();

    void slider_speed_change(int value);
    void slider_angle_change(int value);


    void on_btn_motor_read_pid_clicked();

    void on_btn_motor_write_pid_clicked();

private:
    IVrPickMotor*   m_pMotorCtrl;

private:

    std::list<std::string> _GetDevList();

    void _OpenDevice();

    unsigned int  GetSelectDev();

    QByteArray _HexStringToByteArray(QString HexString);

};



#endif // MAINWINDOW_H
