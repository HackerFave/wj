#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    m_pMotorCtrl(nullptr)
{
    ui->setupUi(this);

    setWindowFlags(Qt::MSWindowsFixedSizeDialogHint);
    setFixedSize(this->width(),this->height());                     // 禁止拖动窗口大小

    connect(ui->slider_speed,       SIGNAL(valueChanged(int)), this, SLOT(slider_speed_change(int)));
    connect(ui->slider_angle,       SIGNAL(valueChanged(int)), this, SLOT(slider_angle_change(int)));

    _OpenDevice();

    ui->show_motor_speed->setText(QString::number(ui->slider_speed->value()));
    ui->show_motor_angle->setText(QString::number(ui->slider_angle->value()));

    std::list<std::string> listSerial = _GetDevList();
    foreach (std::string item , listSerial) {
        ui->comboBox_serial->addItem(QString::fromStdString(item));
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::_OpenDevice()
{
    CreateMotorCtrlObject(&m_pMotorCtrl);
    bool bRet = m_pMotorCtrl->OpenCan(4, 0, 0);
    if(!bRet)
    {
        QMessageBox::warning(this, "警告", "打开设备失败!");
    }
    else
    {
        ui->btn_init->setText(QString("已连接"));
    }
}

unsigned int MainWindow::GetSelectDev()
{
    unsigned int devIndex = 0;
    if(ui->radio_motor_a5->isChecked())
    {
        devIndex = 5;
    }
    else if(ui->radio_motor_a6->isChecked())
    {
        devIndex = 6;
    }
    else if(ui->radio_motor_a7->isChecked())
    {
        devIndex = 7;
    }
    else if(ui->radio_motor_a8->isChecked())
    {
        devIndex = 8;
    }
    return devIndex;
}

QByteArray MainWindow::_HexStringToByteArray(QString HexString)
{
    bool ok;
    QByteArray ret;
    HexString = HexString.trimmed();
    HexString = HexString.simplified();
    QStringList sl = HexString.split(" ");

    foreach (QString s, sl)
    {
        if(!s.isEmpty())
        {
            char c = s.toInt(&ok,16)&0xFF;
            if(ok)
            {
                ret.append(c);
            }
            else
            { }
        }
    }
    return ret;
}

void MainWindow::on_btn_init_clicked()
{
    _OpenDevice();
}

void MainWindow::on_btn_init_serial_clicked()
{
    QString serialName = ui->comboBox_serial->currentText();
    bool bRet = m_pMotorCtrl->OpenSerial(8, serialName.toStdString(), 2500000);
    if(!bRet)
    {
        QMessageBox::warning(this, "警告", "打开串口失败!");
    }
    else
    {
        ui->comboBox_serial->setEnabled(false);
        ui->btn_init_serial->setText(QString("已打开"));
    }
}

void MainWindow::on_btn_can_send_clicked()
{
    //id
    QString text = ui->edit_can_id->text();
    unsigned int canID = text.toUInt();

    //数据
    QString textData = ui->edit_can_data->text();
    QByteArray arrayData = _HexStringToByteArray(textData);

    unsigned char *pArr = (unsigned char*)(arrayData.data());
    unsigned int nArrLen = arrayData.size();

    unsigned char recv[8];
    unsigned int recvLen = 0;
    m_pMotorCtrl->SendCanDataAndRecv(canID, pArr, nArrLen, recv, recvLen);
}

void MainWindow::on_btn_motor_enable_clicked()
{
    unsigned int devIndex = GetSelectDev();
    m_pMotorCtrl->SetEnable(devIndex, true);
}

void MainWindow::on_btn_motor_disable_clicked()
{
    unsigned int devIndex = GetSelectDev();
    m_pMotorCtrl->SetEnable(devIndex, false);
}

void MainWindow::on_btn_motor_run_clicked()
{
    unsigned int devIndex = GetSelectDev();
    int speed = ui->slider_speed->value();
    int pos = ui->slider_angle->value();

    bool bRet = m_pMotorCtrl->CtrlRun(devIndex, pos, speed);
    if(!bRet)
    {
        QMessageBox::warning(this, "警告", "控制失败!");
    }
}

void MainWindow::on_btn_motor_run_zero_clicked()
{
    ui->slider_angle->setValue(0);
    on_btn_motor_run_clicked();
}

void MainWindow::on_btn_motor_foreward_clicked()
{
    unsigned int devIndex = GetSelectDev();
    int speed = ui->slider_speed->value();
    m_pMotorCtrl->CtrlForeward(devIndex, std::abs(speed));
}

void MainWindow::on_btn_motor_reversal_clicked()
{
    unsigned int devIndex = GetSelectDev();
    int speed = ui->slider_speed->value();
    m_pMotorCtrl->CtrlReversal(devIndex, std::abs(speed));
}

void MainWindow::on_btn_motor_stop_clicked()
{
    unsigned int devIndex = GetSelectDev();
    m_pMotorCtrl->CtrlStop(devIndex);
}

void MainWindow::on_btn_motor_zero_clicked()
{
    unsigned int devIndex = GetSelectDev();
    bool bRet = m_pMotorCtrl->SetCurDevZero(devIndex);
    if(!bRet)
    {
        QMessageBox::warning(this, "警告", "设置零点失败!");
    }
    else
    {
        bRet = m_pMotorCtrl->SaveArgToFlash(devIndex);
        if(!bRet)
        {
            QMessageBox::warning(this, "警告", "保存参数失败!");
        }
    }
}

void MainWindow::on_btn_motor_readangle_clicked()
{
    unsigned int devIndex = GetSelectDev();
    float curAngle = 0;
    bool bRet = m_pMotorCtrl->ReadCurAngle(devIndex, curAngle);
    ui->show_motor_cur_angle->setText(QString::number(curAngle ,'f',2));

    long long lMotorAngle = 0;
    bRet = m_pMotorCtrl->ReadMotorAngle(devIndex, lMotorAngle);
    ui->show_motor_cur_motorangle->setText(QString::number(lMotorAngle));
}

void MainWindow::slider_speed_change(int value)
{
    //    ui->show_motor_speed->setText(QString("速度：%1").arg(value));
    ui->show_motor_speed->setText(QString::number(value));
}

void MainWindow::slider_angle_change(int value)
{
    //    ui->show_motor_angle->setText(QString("角度/行程：%1").arg(value));
    ui->show_motor_angle->setText(QString::number(value));
}

void MainWindow::on_btn_motor_read_pid_clicked()
{
    unsigned int devIndex = GetSelectDev();
    int angleKp, angleKi;
    int speedKp, speedKi;
    int forceKp, forceKi;
    bool bRet = m_pMotorCtrl->ReadPID(devIndex, angleKp, angleKi, speedKp, speedKi, forceKp, forceKi);
    ui->edit_pid_pos_p->setText(QString::number(angleKp));
    ui->edit_pid_pos_i->setText(QString::number(angleKi));

    ui->edit_pid_speed_p->setText(QString::number(speedKp));
    ui->edit_pid_speed_i->setText(QString::number(speedKi));

    ui->edit_pid_force_p->setText(QString::number(forceKp));
    ui->edit_pid_force_i->setText(QString::number(forceKi));
}

void MainWindow::on_btn_motor_write_pid_clicked()
{
    unsigned int devIndex = GetSelectDev();

    int angleKp = ui->edit_pid_pos_p->text().toInt();
    int angleKi = ui->edit_pid_pos_i->text().toInt();

    int speedKp = ui->edit_pid_speed_p->text().toInt();
    int speedKi = ui->edit_pid_speed_i->text().toInt();

    int forceKp = ui->edit_pid_force_p->text().toInt();
    int forceKi = ui->edit_pid_force_i->text().toInt();
    m_pMotorCtrl->WritePID(devIndex, angleKp, angleKi, speedKp, speedKi, forceKp, forceKi);
}

std::list<std::string> MainWindow::_GetDevList()
{
    std::list<std::string> serailList;
    serailList.clear();

    //获得所有可用端口列表
    QList<QSerialPortInfo> serialPortInfoList = QSerialPortInfo::availablePorts();
    if(serialPortInfoList.isEmpty()){
        return serailList;
    }
    QList<QSerialPortInfo>::iterator iter = serialPortInfoList.begin();
    //将所有端口添加到界面的下拉列表中
    while(iter!=serialPortInfoList.end()){
        serailList.push_back(iter->portName().toStdString());
        iter++;
    }
    return serailList;
}

