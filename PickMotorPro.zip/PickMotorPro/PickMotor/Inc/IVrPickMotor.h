#ifndef IVRMOTORCTRL_H
#define IVRMOTORCTRL_H

#include <iostream>
#include <IVrPickMotorExport.h>

class PICKMOTOR_EXPORT IVrPickMotor
{
public:
    virtual ~IVrPickMotor(){}

public:
    /// 打开CAN
    virtual bool OpenCan(unsigned long nDevType, unsigned long nDevIndex, unsigned long nCANIndex) = 0;

    /// 关闭CAN
    virtual bool CloseCan(unsigned long nDevType, unsigned long nDevIndex, unsigned long nCANIndex) = 0;

    /// 控制和接收数据
    virtual bool SendCanDataAndRecv(unsigned int canID, const unsigned char data[8], const unsigned int len, unsigned char recv[8],unsigned int& recvLen) = 0;

    /// 串口操作
    virtual bool OpenSerial(unsigned long devIndex, std::string serialName, int baud) = 0;

    /// 关闭串口
    virtual bool CloseSerial(unsigned long devIndex) = 0;

    /// 使能电机
    virtual bool SetEnable(unsigned int devIndex, bool bEnable = true) = 0;

    /// 控制转到指定角度
    virtual bool CtrlRun(unsigned int devIndex, int pos, int speed) = 0;

    /// 正转
    virtual bool CtrlForeward(unsigned int devIndex, int speed) = 0;

    /// 反转
    virtual bool CtrlReversal(unsigned int devIndex, int speed) = 0;

    /// 停止
    virtual bool CtrlStop(unsigned int devIndex) = 0;

    /// 设置零位
    virtual bool SetCurDevZero(unsigned int devIndex) = 0;

    /// 读取末端当前位置 旋转的为电机末端角度； 伸缩的为伸缩位移
    virtual bool ReadCurAngle(unsigned int devIndex, float& fAngle) = 0;

    /// 读取电机位置
    virtual bool ReadMotorAngle(unsigned int devIndex, long long& lAngle) = 0;

    /// 保存参数
    virtual bool SaveArgToFlash(unsigned int devIndex) = 0;

    /// 读写取PID
    virtual bool ReadPID(unsigned int devIndex,
                         int& angleKp, int& angleKi, int& speedKp, int& speedKi, int& forceKp, int& forceKi) = 0;
    virtual bool WritePID(unsigned int devIndex,
                          const int angleKp, const int angleKi, const int speedKp, const int speedKi, const int forceKp, const int forceKi) = 0;

};

PICKMOTOR_EXPORT bool CreateMotorCtrlObject(IVrPickMotor** ppMotorCtrl);

#endif // IVRMOTORCTRL_H

