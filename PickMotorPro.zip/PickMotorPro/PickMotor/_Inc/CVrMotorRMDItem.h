#ifndef CVRMOTORRMDIME_H
#define CVRMOTORRMDIME_H

class CVrMotorRMDItem
{
public:
    CVrMotorRMDItem();
    ~CVrMotorRMDItem();

    // 使能
    void GetEnableData(unsigned char pData[8], unsigned int& nLen, long long lCurPos, bool bEnable = true);

    // 获取末端角度
    void GetReadAngle(unsigned char pData[8], unsigned int& nLen);
    int  ParseAngleData(const unsigned char pData[8], const unsigned int nLen);

    // 获取电机的角度
    void GetReadMotorAngle(unsigned char pData[8], unsigned int& nLen);
    long long ParseMotorAngle(unsigned char pData[8], unsigned int& nLen);

    // 设置零位
    void SetDevZero(unsigned char pData[], unsigned int &nLen);
    void SetEncoderOneAngle(unsigned char* pData, unsigned int &nLen);
    void SetEncoderMultiAngle(unsigned char* pData, unsigned int &nLen);

    // 控制运行
    void CtrlRun(unsigned char pData[8], unsigned int &nLen, int speed);

    // 控制绝对运行
    void CtrlRun(unsigned char pData[8], unsigned int &nLen, int pos, int speed);

    // 控制停止
    void CtrlStop(unsigned char pData[8], unsigned int &nLen);

    // 读取PID
    void ReadPID(unsigned char* pData, unsigned int &nLen);
    void WritePID(unsigned char* pData, unsigned int &nLen, const int angleP, const int angleI,
                  const int speedP, const int speedI, const int forceP, const int forceI);
    void ParsePID(unsigned char* pData, unsigned int nLen, int& angleP, int& angleI,
                  int& speedP, int& speedI, int& forceP, int& forceI);

    /// 保存参数
    void SaveArgToFlash(unsigned char pData[8], unsigned int &nLen);

};

#endif
