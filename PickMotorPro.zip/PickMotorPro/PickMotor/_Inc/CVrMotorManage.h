#ifndef CVRMOTORMANAGE_H
#define CVRMOTORMANAGE_H

#include <map>
#include "CVrMotorRMDItem.h"
#include "CVrMotorXinTuoItem.h"

#include "VrLog.h"

class CVrMotorManage
{
public:
    CVrMotorManage();
    ~CVrMotorManage();

    // 获取CANID
    unsigned int GetCANID(unsigned int devIndex);

    // 使能
    void GetEnableData(unsigned int devIndex, unsigned char pData[8], unsigned int& nLen, long long lCurPos = 0, bool bEnable = true);

    // 获取末端的角度
    void  GetReadAngleData(unsigned int devIndex, unsigned char pData[8], unsigned int& nLen);
    float ParseAngleData(unsigned int devIndex, const unsigned char pData[8], const unsigned int nLen);

    // 获取电机的角度
    void  GetReadMotorAngleData(unsigned int devIndex, unsigned char pData[8], unsigned int& nLen);
    long long  ParseMotorAngleData(unsigned int devIndex, unsigned char pData[8], unsigned int& nLen);

    // 设置零位
    void SetDevZero(unsigned int devIndex, unsigned char* pData, unsigned int &nLen);
    void SetEncoderOneAngle(unsigned int devIndex, unsigned char* pData, unsigned int &nLen);
    void SetEncoderMultiAngle(unsigned int devIndex, unsigned char* pData, unsigned int &nLen);

    // 控制运行
    void CtrlRun(unsigned int devIndex, unsigned char* pData, unsigned int &nLen, int speed);

    // 控制绝对运行
    bool CtrlRun(unsigned int devIndex, unsigned char* pData, unsigned int &nLen, float fCurPos, int nMotorCurPos, float fToPos, int speed);

    // 控制停止
    void CtrlStop(unsigned int devIndex, unsigned char* pData, unsigned int &nLen);

    // 读取PID
    void ReadPID(unsigned int devIndex, unsigned char* pData, unsigned int &nLen);
    void WritePID(unsigned int devIndex, unsigned char* pData, unsigned int &nLen, const int angleP, const int angleI,
                  const int speedP, const int speedI, const int forceP, const int forceI);
    void ParsePID(unsigned int devIndex, unsigned char* pData, unsigned int nLen, int& angleP, int& angleI,
                  int& speedP, int& speedI, int& forceP, int& forceI);
    /// 保存参数
    void SaveArgToFlash(unsigned int devIndex, unsigned char pData[8], unsigned int &nLen);

private:
    CVrMotorRMDItem*                m_pMotorRMD;
    CVrMotorXinTuoItem*             m_pMotorXinTuo;
};

#endif

