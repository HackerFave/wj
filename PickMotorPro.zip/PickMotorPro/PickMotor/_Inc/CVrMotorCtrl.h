#ifndef CVRMOTORCTRL_H
#define CVRMOTORCTRL_H

#include <iostream>
#include "IVrPickMotor.h"
#include "CVrMotorManage.h"
#include "ControlCAN.h"

#include "VrLog.h"

#include "VrSerialPort.h"

class CVrMotorCtrl : public IVrPickMotor
{
public:
    CVrMotorCtrl();
    virtual ~CVrMotorCtrl();

public:
    /// 打开CAN
    virtual bool OpenCan(unsigned long nDevType, unsigned long nDevIndex, unsigned long nCANIndex);

    /// 关闭CAN
    virtual bool CloseCan(unsigned long nDevType, unsigned long nDevIndex, unsigned long nCANIndex);

    /// 控制和接收数据
    virtual bool SendCanDataAndRecv(unsigned int canID, const unsigned char data[8], const unsigned int len, unsigned char recv[8], unsigned int& recvLen);

    /// 串口操作
    virtual bool OpenSerial(unsigned long devIndex, std::string serialName, int baud);

    /// 关闭串口
    virtual bool CloseSerial(unsigned long devIndex);

    /// 使能电机
    virtual bool SetEnable(unsigned int devIndex, bool bEnable = true);

    /// 控制转到指定角度
    virtual bool CtrlRun(unsigned int devIndex, int pos, int speed);

    /// 正转
    virtual bool CtrlForeward(unsigned int devIndex, int speed);

    /// 反转
    virtual bool CtrlReversal(unsigned int devIndex, int speed);

    /// 停止
    virtual bool CtrlStop(unsigned int devIndex);

    /// 设置零位
    virtual bool SetCurDevZero(unsigned int devIndex);

    /// 读取当前位置
    virtual bool ReadCurAngle(unsigned int devIndex, float& fAngle);

    /// 读取电机位置
    virtual bool ReadMotorAngle(unsigned int devIndex, long long& lAngle);

    /// 保存参数
    virtual bool SaveArgToFlash(unsigned int devIndex);

    /// 读写取PID
    virtual bool ReadPID(unsigned int devIndex,
                         int& angleP, int& angleI, int& speedP, int& speedI, int& forceP, int& forceI);
    virtual bool WritePID(unsigned int devIndex,
                          const int angleP, const int angleI, const int speedP, const int speedI, const int forceP, const int forceI);

private:
    DWORD   m_nDevType;       /* USBCAN-2A或USBCAN-2C或CANalyst-II */
    DWORD   m_nDevIndex;      /* 第1个设备 */
    DWORD   m_nCANIndex;      /* 第1个通道 */

    CVrMotorManage*                 m_pMotorManage;
    std::map<int, CVrSerialPort*>   m_mapSerialPort;

};

#endif // CVRMOTORCTRL_H
