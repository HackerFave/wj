#include "CVrMotorCtrl.h"
#include "StringUtils.h"
#include "VrTimeUtils.h"
#pragma comment(lib, "ControlCAN.lib")

#define USECAN

CVrMotorCtrl::CVrMotorCtrl()
{
    m_pMotorManage = new CVrMotorManage;
}

CVrMotorCtrl::~CVrMotorCtrl()
{
    delete m_pMotorManage;
    m_pMotorManage = nullptr;
}

bool CVrMotorCtrl::OpenCan(unsigned long nDevType, unsigned long nDevIndex, unsigned long nCANIndex)
{
    DWORD nRet = 0;
    m_nDevType   = nDevType;  /* USBCAN-2A或USBCAN-2C或CANalyst-II */
    m_nDevIndex  = nDevIndex; /* 第1个设备 */
    m_nCANIndex  = nCANIndex; /* 第1个通道 */
#ifdef USECAN
    nRet = VCI_OpenDevice(m_nDevType, m_nDevIndex, 0);
    if(1 == nRet)
    {
        VCI_INIT_CONFIG config;
        config.AccCode = 0x80000000;
        config.AccMask = 0xffffffff;
        config.Filter = 0;
        config.Timing0 = 0x00;
        config.Timing1 = 0x14;
        config.Mode = 0;

        nRet = VCI_InitCAN(m_nDevType, m_nDevIndex, m_nCANIndex, &config);

        if(1 == nRet)
        {
            nRet = VCI_StartCAN(m_nDevType, m_nDevIndex, m_nCANIndex);
        }
    }
#endif
    return 1 == nRet;
}

bool CVrMotorCtrl::CloseCan(unsigned long nDevType, unsigned long nDevIndex, unsigned long nCANIndex)
{
#ifdef USECAN
    VCI_CloseDevice(nDevType, nDevIndex);
#endif
    return true;
}

bool CVrMotorCtrl::SendCanDataAndRecv(unsigned int canID, const unsigned char* data, const unsigned int len, unsigned char* recv, unsigned int &recvLen)
{
    bool bRet = false;

#ifdef USECAN
    if(len == 0) return true;
    if(len > 8) return false;

    CVrTimeUtils oTimeUtils;
    oTimeUtils.Update();

    VCI_CAN_OBJ canSendObj, canRecvObj;
    memset(&canSendObj, 0, sizeof(VCI_CAN_OBJ));
    memset(&canRecvObj, 0, sizeof(VCI_CAN_OBJ));

    canSendObj.ID         = canID;
    canSendObj.TimeFlag   = 0;
    canSendObj.TimeStamp  = QDateTime::currentDateTime().toTime_t();
    canSendObj.ExternFlag = 0;
    canSendObj.RemoteFlag = 0;
    canSendObj.SendType   = 1;

    memcpy(canSendObj.Data, data, len);
    canSendObj.DataLen = static_cast<unsigned char>(len);

    qDebug("Tx [0x%3x] Len: %d Data: %02x %02x %02x %02x %02x %02x %02x %02x", canSendObj.ID,
           canSendObj.DataLen,
           canSendObj.Data[0], canSendObj.Data[1], canSendObj.Data[2], canSendObj.Data[3],
           canSendObj.Data[4], canSendObj.Data[5], canSendObj.Data[6], canSendObj.Data[7]);

    VCI_ClearBuffer(m_nDevType, m_nDevIndex, m_nCANIndex);
    memset(recv, 0 , 8);

    ULONG nRet = VCI_Transmit(m_nDevType, m_nDevIndex, m_nCANIndex, &canSendObj, (ULONG)len);
    if(nRet > 0)
    {
        //等待有数据
        CVrTimeUtils waitTime;
        waitTime.Update();
        do{
            nRet = VCI_GetReceiveNum(m_nDevType, m_nDevIndex, m_nCANIndex);
            if(waitTime.GetElapsedTimeInMilliSec() > 1000)
            {
                nRet = 0;
                bRet = false;
                break;
            }
        } while(0 == nRet);
        //接收数据
        if(nRet > 0)
        {
            nRet = VCI_Receive(m_nDevType, m_nDevIndex, m_nCANIndex, &canRecvObj, 2500, 0 );
            if(nRet > 0)
            {
                bRet = true;
                recvLen = canRecvObj.DataLen > 8 ? 8 : canRecvObj.DataLen;
                memcpy(recv, canRecvObj.Data, recvLen);
            }
        }
    }
    qDebug("Rx [0x%3x] Len: %d Data: %02x %02x %02x %02x %02x %02x %02x %02x", canRecvObj.ID ,
           canRecvObj.DataLen,
           canRecvObj.Data[0], canRecvObj.Data[1], canRecvObj.Data[2], canRecvObj.Data[3],
           canRecvObj.Data[4], canRecvObj.Data[5], canRecvObj.Data[6], canRecvObj.Data[7]);
    qDebug("%s time: %.3f", __func__, oTimeUtils.GetElapsedTimeInMilliSec());
#endif
    return bRet;
}

bool CVrMotorCtrl::OpenSerial(unsigned long devIndex, std::string serialName, int baud)
{
    if(8 != devIndex) return false;
    CVrSerialPort* pSerialPort = new CVrSerialPort;
    bool bRet = pSerialPort->OpenDev(serialName, baud);
    if(bRet)
    {
        m_mapSerialPort.insert(std::make_pair(8, pSerialPort));
    }
    return bRet;
}

bool CVrMotorCtrl::CloseSerial(unsigned long devIndex)
{
    std::map<int, CVrSerialPort*>::iterator iter = m_mapSerialPort.find(devIndex);
    if(iter != m_mapSerialPort.end())
    {
        CVrSerialPort* pSerialPort = iter->second;
        pSerialPort->CloseDev();
        m_mapSerialPort.erase(iter);
    }
    return true;
}

bool CVrMotorCtrl::SetEnable(unsigned int devIndex, bool bEnable)
{
    unsigned char requestData[8];
    unsigned int  requestLen = 0;
    unsigned char recvData[8];
    unsigned int  recvLen = 0;

    /// 获取当前
    long long lMotorPos = 0;
    bool bRet = ReadMotorAngle(devIndex, lMotorPos);
    if(!bRet) return false;

    ///1. 使能设备
    // 填写请求数据
    m_pMotorManage->GetEnableData(devIndex, requestData, requestLen, lMotorPos, bEnable);

    // 发送并接收数据
    bRet = SendCanDataAndRecv(m_pMotorManage->GetCANID(devIndex), requestData, requestLen, recvData, recvLen);
    return bRet;
}

bool CVrMotorCtrl::CtrlRun(unsigned int devIndex, int pos, int speed)
{
    unsigned char requestData[8];
    unsigned int  requestLen = 0;
    unsigned char recvData[8];
    unsigned int  recvLen = 0;

    unsigned int canID = m_pMotorManage->GetCANID(devIndex);
    bool bRet = false;

    //读取电机角度
    long long curMotorAngle = 0;
    bRet = ReadMotorAngle(devIndex, curMotorAngle);
    if(!bRet) return false;

    LOG_DEBUG("%d", __LINE__);
    // 读取角度
    float fAngle = 0;
    bRet = ReadCurAngle(devIndex, fAngle);
    if(!bRet) return false;

    LOG_DEBUG("%d", __LINE__);
    // 填写请求数据
    bRet = m_pMotorManage->CtrlRun(devIndex, requestData, requestLen, fAngle, curMotorAngle, pos, speed);
    if(!bRet) return false;

    // 发送并接收数据
    bRet = SendCanDataAndRecv(canID, requestData, requestLen, recvData, recvLen);
    return bRet;
}

bool CVrMotorCtrl::CtrlForeward(unsigned int devIndex, int speed)
{
    unsigned char requestData[8];
    unsigned int  requestLen = 0;
    unsigned char recvData[8];
    unsigned int  recvLen = 0;

    // 填写请求数据
    m_pMotorManage->CtrlRun(devIndex, requestData, requestLen, std::abs(speed));

    unsigned int canID = m_pMotorManage->GetCANID(devIndex);
    // 发送并接收数据
    bool bRet = SendCanDataAndRecv(canID, requestData, requestLen, recvData, recvLen);
    return bRet;
}

bool CVrMotorCtrl::CtrlReversal(unsigned int devIndex, int speed)
{
    unsigned char requestData[8];
    unsigned int  requestLen = 0;
    unsigned char recvData[8];
    unsigned int  recvLen = 0;

    // 填写请求数据
    m_pMotorManage->CtrlRun(devIndex, requestData, requestLen, -1 * std::abs(speed));

    // 发送并接收数据
    bool bRet = SendCanDataAndRecv(m_pMotorManage->GetCANID(devIndex), requestData, requestLen, recvData, recvLen);
    return bRet;
}

bool CVrMotorCtrl::CtrlStop(unsigned int devIndex)
{
    unsigned char requestData[8];
    unsigned int  requestLen = 0;
    unsigned char recvData[8];
    unsigned int  recvLen = 0;

    // 填写请求数据
    m_pMotorManage->CtrlStop(devIndex, requestData, requestLen);

    // 发送并接收数据
    bool bRet = SendCanDataAndRecv(m_pMotorManage->GetCANID(devIndex), requestData, requestLen, recvData, recvLen);
    return bRet;
}

bool CVrMotorCtrl::SetCurDevZero(unsigned int devIndex)
{
    unsigned char requestData[8];
    unsigned int  requestLen = 0;
    unsigned char recvData[8];
    unsigned int  recvLen = 0;


    if(8 == devIndex)
    {
        std::map<int, CVrSerialPort*>::iterator iter = m_mapSerialPort.find(devIndex);
        bool bRet = true;
        if(iter != m_mapSerialPort.end())
        {
            CVrSerialPort* pSerialPort = iter->second;
            int nCount = 10;
            while(nCount--)
            {
                m_pMotorManage->SetEncoderOneAngle(devIndex, requestData, requestLen);
                bRet &= pSerialPort->SendDataAndRecv(requestData, requestLen, recvData, recvLen);
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
            }
            nCount = 10;
            while(nCount--)
            {
                m_pMotorManage->SetEncoderMultiAngle(devIndex, requestData, requestLen);
                bRet &= pSerialPort->SendDataAndRecv(requestData, requestLen, recvData, recvLen);
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
            }
        }
        return true;
    }
    else
    {
        // 填写请求数据
        m_pMotorManage->SetDevZero(devIndex, requestData, requestLen);

        // 发送并接收数据
        bool bRet = SendCanDataAndRecv(m_pMotorManage->GetCANID(devIndex), requestData, requestLen, recvData, recvLen);

        return bRet;
    }

}

bool CVrMotorCtrl::ReadCurAngle(unsigned int devIndex, float& fAngle)
{
    unsigned char requestData[8];
    unsigned int  requestLen = 0;
    unsigned char recvData[16];
    unsigned int  recvLen = 0;
    bool bRet = false;
    // 填写请求数据
    m_pMotorManage->GetReadAngleData(devIndex, requestData, requestLen);

    if(8 != devIndex)   //从CAN读取角度
    {
        // 发送并接收数据
        bRet = SendCanDataAndRecv(m_pMotorManage->GetCANID(devIndex), requestData, requestLen, recvData, recvLen);
        if(bRet)
        {
            // 解析角度
            fAngle = m_pMotorManage->ParseAngleData(devIndex, recvData, recvLen);
        }
    }
    else    //从串口读取数据
    {
        std::map<int, CVrSerialPort*>::iterator iter = m_mapSerialPort.find(devIndex);
        if(iter != m_mapSerialPort.end())
        {
            CVrSerialPort* pSerialPort = iter->second;
            m_pMotorManage->GetReadAngleData(devIndex, requestData, requestLen);
            bRet = pSerialPort->SendDataAndRecv(requestData, requestLen, recvData, recvLen);
            if(bRet)
            {
                // 解析角度
                fAngle = -1 * m_pMotorManage->ParseAngleData(devIndex, recvData, recvLen);
            }
        }
    }

    return bRet;
}

bool CVrMotorCtrl::ReadMotorAngle(unsigned int devIndex, long long& lAngle)
{
    unsigned char requestData[8];
    unsigned int  requestLen = 0;
    unsigned char recvData[8];
    unsigned int  recvLen = 0;

    // 填写请求数据
    m_pMotorManage->GetReadMotorAngleData(devIndex, requestData, requestLen);

    // 发送并接收数据
    bool bRet = SendCanDataAndRecv(m_pMotorManage->GetCANID(devIndex), requestData, requestLen, recvData, recvLen);
    if(bRet)
    {
        // 解析角度
        lAngle = m_pMotorManage->ParseMotorAngleData(devIndex, recvData, recvLen);
    }

    return bRet;
}

bool CVrMotorCtrl::SaveArgToFlash(unsigned int devIndex)
{
    unsigned char requestData[8];
    unsigned int  requestLen = 0;
    unsigned char recvData[8];
    unsigned int  recvLen = 0;

    // 填写请求数据
    m_pMotorManage->SaveArgToFlash(devIndex, requestData, requestLen);

    // 发送并接收数据
    bool bRet = SendCanDataAndRecv(m_pMotorManage->GetCANID(devIndex), requestData, requestLen, recvData, recvLen);
    return bRet;
}

bool CVrMotorCtrl::ReadPID(unsigned int devIndex, int &angleP, int &angleI, int &speedP, int &speedI, int &forceP, int &forceI)
{
    unsigned char requestData[8];
    unsigned int  requestLen = 0;
    unsigned char recvData[8];
    unsigned int  recvLen = 0;

    // 填写请求数据
    m_pMotorManage->ReadPID(devIndex, requestData, requestLen);

    // 发送并接收数据
    bool bRet = SendCanDataAndRecv(m_pMotorManage->GetCANID(devIndex), requestData, requestLen, recvData, recvLen);
    if(bRet)
    {
        m_pMotorManage->ParsePID(devIndex, recvData, recvLen, angleP, angleI, speedP, speedI, forceP, forceI);
    }
    return bRet;
}

bool CVrMotorCtrl::WritePID(unsigned int devIndex, const int angleP, const int angleI, const int speedP, const int speedI, const int forceP, const int forceI)
{
    unsigned char requestData[8];
    unsigned int  requestLen = 0;
    unsigned char recvData[8];
    unsigned int  recvLen = 0;

    // 填写请求数据
    m_pMotorManage->WritePID(devIndex, requestData, requestLen, angleP, angleI, speedP, speedI, forceP, forceI);

    // 发送并接收数据
    bool bRet = SendCanDataAndRecv(m_pMotorManage->GetCANID(devIndex), requestData, requestLen, recvData, recvLen);
    return bRet;
}

bool CreateMotorCtrlObject(IVrPickMotor** ppPickMotor)
{
    if(nullptr == ppPickMotor) return false;
    CVrMotorCtrl* p = new CVrMotorCtrl;
    *ppPickMotor = p;
    return true;
}
