#include "CVrMotorXinTuoItem.h"
#include <cmath>

CVrMotorXinTuoItem::CVrMotorXinTuoItem()
{

}

CVrMotorXinTuoItem::~CVrMotorXinTuoItem()
{

}

void CVrMotorXinTuoItem::GetEnableData(unsigned char* pData, unsigned int &nLen, bool bEnable)
{
    pData[0] = 0xFF;
    pData[1] = 0x80;

    pData[2] = 0x00;
    pData[3] = 0x00;
    pData[4] = 0x00;
    pData[5] = bEnable ? 0x01 : 0x00;

    nLen = 6;
}

void CVrMotorXinTuoItem::GetReadAngle(unsigned char* pData, unsigned int &nLen)
{
    pData[0] = 0xFF;
    pData[1] = 0x11;

    nLen = 2;
}

int CVrMotorXinTuoItem::ParseAngleData(const unsigned char* pData, const unsigned int nLen)
{
    int nAngle = 0;
    unsigned char* cAngle = (unsigned char*)(&nAngle);

    cAngle[3] = pData[2];
    cAngle[2] = pData[3];
    cAngle[1] = pData[4];
    cAngle[0] = pData[5];
    return nAngle;
}

void CVrMotorXinTuoItem::GetReadMotorAngle(unsigned char* pData, unsigned int &nLen)
{
    pData[0] = 0xFF;
    pData[1] = 0x03;

    nLen = 2;
}

long long CVrMotorXinTuoItem::ParseMotorAngle(unsigned char* pData, unsigned int &nLen)
{
    int nAngle = 0;
    unsigned char* cAngle = (unsigned char*)(&nAngle);

    cAngle[3] = pData[2];
    cAngle[2] = pData[3];
    cAngle[1] = pData[4];
    cAngle[0] = pData[5];
    return nAngle;
}

void CVrMotorXinTuoItem::SetDevZero(unsigned char* pData, unsigned int &nLen)
{
    pData[0] = 0xFF;
    pData[1] = 0x89;

    pData[2] = 0x00;
    pData[3] = 0x00;
    pData[4] = 0x00;
    pData[5] = 0x01;

    nLen = 6;
}

void CVrMotorXinTuoItem::CtrlRun(unsigned char* pData, unsigned int &nLen, int speed)
{
    pData[0] = 0xFF;
    pData[1] = 0x86;

    unsigned char* cSpeed = (unsigned char *)(&speed);

    pData[2] = cSpeed[3];
    pData[3] = cSpeed[2];
    pData[4] = cSpeed[1];
    pData[5] = cSpeed[0];

    nLen = 6;
}

void CVrMotorXinTuoItem::CtrlRun(unsigned char* pData, unsigned int &nLen, int pos, int speed)
{
    pData[0] = 0xFF;
    pData[1] = 0x82;

    unsigned char* cPos = (unsigned char *)(&pos);

    pData[2] = cPos[3];
    pData[3] = cPos[2];
    pData[4] = cPos[1];
    pData[5] = cPos[0];

    speed = std::abs(speed);
    pData[6] = static_cast<unsigned char>(speed / 256);
    pData[7] = static_cast<unsigned char>(speed % 256);
    nLen = 8;
}

void CVrMotorXinTuoItem::CtrlStop(unsigned char* pData, unsigned int &nLen)
{
    pData[0] = 0xFF;
    pData[1] = 0x87;

    pData[2] = 0x00;
    pData[3] = 0x00;
    pData[4] = 0x00;
    pData[5] = 0x01;

    nLen = 6;
}

void CVrMotorXinTuoItem::ReadPID(unsigned char *pData, unsigned int &nLen)
{

}

void CVrMotorXinTuoItem::WritePID(unsigned char *pData, unsigned int &nLen, const int angleP, const int angleI, const int speedP, const int speedI, const int forceP, const int forceI)
{

}

void CVrMotorXinTuoItem::ParsePID(unsigned char *pData, unsigned int nLen, int &angleP, int &angleI, int &speedP, int &speedI, int &forceP, int &forceI)
{

}

void CVrMotorXinTuoItem::SaveArgToFlash(unsigned char* pData, unsigned int &nLen)
{
    pData[0] = 0xFF;
    pData[1] = 0x95;

    pData[2] = 0x00;
    pData[3] = 0x00;
    pData[4] = 0x00;
    pData[5] = 0x01;

    nLen = 6;
}
