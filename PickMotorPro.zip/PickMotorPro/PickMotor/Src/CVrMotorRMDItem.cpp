#include "CVrMotorRMDItem.h"
#include <cmath>
#include "VrLog.h"

CVrMotorRMDItem::CVrMotorRMDItem()
{

}

CVrMotorRMDItem::~CVrMotorRMDItem()
{

}

void CVrMotorRMDItem::GetEnableData(unsigned char* pData, unsigned int &nLen, long long lCurPos, bool bEnable)
{
    pData[0] = 0xA4;
    pData[1] = 0x00;

    int speed = 100;
    pData[2] = static_cast<unsigned char>(speed % 256);
    pData[3] = static_cast<unsigned char>(speed / 256);

    int pos = lCurPos;
    unsigned char* cPos = (unsigned char *)(&pos);

    pData[4] = cPos[0];
    pData[5] = cPos[1];
    pData[6] = cPos[2];
    pData[7] = cPos[3];

    nLen = 8;
}

void CVrMotorRMDItem::GetReadAngle(unsigned char* pData, unsigned int &nLen)
{
    //从串口请求数据
    pData[0] = 0x1A;
    nLen = 1;
}

int CVrMotorRMDItem::ParseAngleData(const unsigned char* pData, const unsigned int nLen)
{
    unsigned int nSingleAngle = *((unsigned int *)(pData + 2));
    nSingleAngle &= 0x00FFFFFF;

    unsigned int nCircleNum = *((unsigned int*)(pData + 6));
    nCircleNum &= 0x00FFFFFF;

    return nCircleNum * 524288 + nSingleAngle;
}

void CVrMotorRMDItem::GetReadMotorAngle(unsigned char* pData, unsigned int &nLen)
{
    pData[0] = 0x92;
    nLen = 8;
}

long long CVrMotorRMDItem::ParseMotorAngle(unsigned char* pData, unsigned int &nLen)
{
    long long nAngle = *((long long*)pData);
    nAngle = nAngle >> 8; //最低位不是数据
    return nAngle;
}

void CVrMotorRMDItem::SetDevZero(unsigned char pData[], unsigned int &nLen)
{
    pData[0] = 0x19;
    nLen = 8;
}

void CVrMotorRMDItem::SetEncoderOneAngle(unsigned char *pData, unsigned int &nLen)
{
    //从串口请求数据
    pData[0] = 0xC2;
    nLen = 1;
}

void CVrMotorRMDItem::SetEncoderMultiAngle(unsigned char *pData, unsigned int &nLen)
{
    //从串口请求数据
    pData[0] = 0x62;
    nLen = 1;
}

void CVrMotorRMDItem::CtrlRun(unsigned char* pData, unsigned int &nLen, int speed)
{
    pData[0] = 0xA2;
    pData[1] = 0x00;
    pData[2] = 0x00;
    pData[3] = 0x00;

    unsigned char* cSpeed = (unsigned char *)(&speed);

    pData[4] = cSpeed[0];
    pData[5] = cSpeed[1];
    pData[6] = cSpeed[2];
    pData[7] = cSpeed[3];

    nLen = 8;
}

void CVrMotorRMDItem::CtrlRun(unsigned char* pData, unsigned int &nLen, int pos, int speed)
{
    pData[0] = 0xA4;
    pData[1] = 0x00;

    speed = std::abs(speed);
    pData[2] = static_cast<unsigned char>(speed % 256);
    pData[3] = static_cast<unsigned char>(speed / 256);

    unsigned char* cPos = (unsigned char *)(&pos);

    pData[4] = cPos[0];
    pData[5] = cPos[1];
    pData[6] = cPos[2];
    pData[7] = cPos[3];

    nLen = 8;
}

void CVrMotorRMDItem::CtrlStop(unsigned char* pData, unsigned int &nLen)
{
    pData[0] = 0x81;
    nLen = 8;
}

void CVrMotorRMDItem::ReadPID(unsigned char *pData, unsigned int &nLen)
{
    pData[0] = 0x30;
    nLen = 8;
}

void CVrMotorRMDItem::WritePID(unsigned char *pData, unsigned int &nLen, const int angleP, const int angleI, const int speedP, const int speedI, const int forceP, const int forceI)
{
    pData[0] = 0x32;
    pData[1] = 0;
    pData[2] = angleP;
    pData[3] = angleI;
    pData[4] = speedP;
    pData[5] = speedI;
    pData[6] = forceP;
    pData[7] = forceI;
    nLen = 8;
}

void CVrMotorRMDItem::ParsePID(unsigned char *pData, unsigned int nLen, int &angleP, int &angleI, int &speedP, int &speedI, int &forceP, int &forceI)
{
    angleP = pData[2];
    angleI = pData[3];
    speedP = pData[4];
    speedI = pData[5];
    forceP = pData[6];
    forceI = pData[7];
}

void CVrMotorRMDItem::SaveArgToFlash(unsigned char* pData, unsigned int &nLen)
{

}
