#include "CVrMotorManage.h"
#include <iostream>
#include <string>

struct DevConfig
{
    int nDevIndex;
    unsigned int nCanID;

    bool  bEnable;

    float fRatio;   //减速比

    float fMinSpeed;
    float fMaxSpeed;

    float fMinPos;
    float fMaxPos;
};

static const int devNum = 8;
static DevConfig devConfig[devNum] = {
    //序号  CANID    是否可用    减速比                    最大小速       软限位
    {1 ,    0 ,     false,      0,                      0, 0,       0,   0,        },
    {2 ,    0 ,     false,      0,                      0, 0,       0,   0,        },
    {3 ,    0 ,     false,      0,                      0, 0,       0,   0,        },
    {4 ,    0 ,     false,      0,                      0, 0,       0,   0,        },
    {5 ,    0x1 ,   true,       101.f / 1,              0, 0,       -20, 20,       },
    {6 ,    0x2 ,   true,       101.f / 1,              0, 0,       -20, 20,       },
    {7 ,    0x142 , true,       17 * 8 / 15.f / 360.f,  0, 0,       -50, 50,      },
    {8 ,    0x143 , true,       17 * 8 / 15.f / 360.f,  0, 0,       -50, 50,      },    //单圈位移 17 * 8 / 15.f mm
};

CVrMotorManage::CVrMotorManage()
{
    m_pMotorXinTuo = new CVrMotorXinTuoItem;
    m_pMotorRMD = new CVrMotorRMDItem;
}

CVrMotorManage::~CVrMotorManage()
{
    delete m_pMotorRMD;
    m_pMotorRMD = nullptr;

    delete m_pMotorXinTuo;
    m_pMotorXinTuo = nullptr;
}

unsigned int CVrMotorManage::GetCANID(unsigned int devIndex)
{
    if(devIndex <= 0 || devIndex > 8) return 0;
    return devConfig[devIndex - 1].nCanID;
}

void CVrMotorManage::GetEnableData(unsigned int devIndex, unsigned char* pData, unsigned int &nLen, long long lCurPos, bool bEnable)
{
    memset(pData, 0 , 8);
    switch (devIndex) {
    case 5:
    case 6:
        m_pMotorXinTuo->GetEnableData(pData, nLen, bEnable);
        break;

    case 7:
    case 8:
        m_pMotorRMD->GetEnableData(pData, nLen, lCurPos, bEnable);
        break;
    }
}

void CVrMotorManage::GetReadAngleData(unsigned int devIndex,  unsigned char* pData, unsigned int &nLen)
{
    memset(pData, 0 , 8);
    switch (devIndex) {
    case 5:
    case 6:
        m_pMotorXinTuo->GetReadAngle(pData, nLen);
        break;

    case 8:
        m_pMotorRMD->GetReadAngle(pData, nLen);
        break;
    default:
        nLen = 0;
        break;
    }
}

float CVrMotorManage::ParseAngleData(unsigned int devIndex, const unsigned char* pData, const unsigned int nLen)
{
    float fAngle = 0;
    int nRawAngle = 0;
    switch (devIndex) {
    case 5:
    case 6:
        nRawAngle = m_pMotorXinTuo->ParseAngleData(pData, nLen);
        fAngle = nRawAngle / (32768.f / 360.f);

        if(fAngle > 180) fAngle -= 360.f;
        break;

    case 8:
    {
        nRawAngle = m_pMotorRMD->ParseAngleData(pData, nLen);
        fAngle = nRawAngle * (360.f / 524288.f);  //电机当前角度
        fAngle *= devConfig[devIndex - 1].fRatio;
    }
        break;
    default:
        fAngle = 0;
        break;
    }
    return fAngle;
}

void CVrMotorManage::GetReadMotorAngleData(unsigned int devIndex, unsigned char* pData, unsigned int &nLen)
{
    memset(pData, 0 , 8);
    switch (devIndex) {
    case 5:
    case 6:
        m_pMotorXinTuo->GetReadMotorAngle(pData, nLen);
        break;

    case 7:
    case 8:
        m_pMotorRMD->GetReadMotorAngle(pData, nLen);
        break;
    }
}

long long CVrMotorManage::ParseMotorAngleData(unsigned int devIndex, unsigned char* pData, unsigned int &nLen)
{
    long long nRawAngle = 0;
    switch (devIndex) {
    case 5:
    case 6:
        nRawAngle = m_pMotorXinTuo->ParseMotorAngle(pData, nLen);
        break;

    case 7:
    case 8:
        nRawAngle = m_pMotorRMD->ParseMotorAngle(pData, nLen);
        break;
    }
    return nRawAngle;
}

void CVrMotorManage::SetDevZero(unsigned int devIndex, unsigned char pData[], unsigned int &nLen)
{
    memset(pData, 0 , 8);
    switch (devIndex) {
    case 5:
    case 6:
        m_pMotorXinTuo->SetDevZero(pData, nLen);
        break;

    case 7:
    case 8:
        m_pMotorRMD->SetDevZero(pData, nLen);
        break;
    }
}

void CVrMotorManage::SetEncoderOneAngle(unsigned int devIndex, unsigned char *pData, unsigned int &nLen)
{
    memset(pData, 0 , 8);
    switch (devIndex) {

    case 8:
        m_pMotorRMD->SetEncoderOneAngle(pData, nLen);
        break;
    }
}

void CVrMotorManage::SetEncoderMultiAngle(unsigned int devIndex, unsigned char *pData, unsigned int &nLen)
{
    memset(pData, 0 , 8);
    switch (devIndex) {
    case 8:
        m_pMotorRMD->SetEncoderMultiAngle(pData, nLen);
        break;
    }
}

void CVrMotorManage::CtrlRun(unsigned int devIndex, unsigned char* pData, unsigned int &nLen, int speed)
{
    memset(pData, 0 , 8);
    nLen = 0;
    switch (devIndex) {
    case 5:
    case 6:
        m_pMotorXinTuo->CtrlRun(pData, nLen, static_cast<int>(speed * devConfig[devIndex - 1].fRatio / 6)); //控制单位是【转/分钟】期望单位 度/秒
        break;

    case 7:
    case 8:
        m_pMotorRMD->CtrlRun(pData, nLen, static_cast<int>(speed * 1.0f / devConfig[devIndex - 1].fRatio * 100));  //100 是电机的单位
        break;
    }
}

bool CVrMotorManage::CtrlRun(unsigned int devIndex, unsigned char* pData, unsigned int &nLen, float fCurPos, int nMotorCurPos, float fToPos, int speed)
{
    //只能根据当前位置进行相对计算来获取下一个位置
    memset(pData, 0 , 8);
    nLen = 0;

    if(fToPos < devConfig[devIndex - 1].fMinPos || fToPos > devConfig[devIndex - 1].fMaxPos)
    {
        return false;
    }

    switch (devIndex) {
        case 5:
        case 6:
        {
            int nToMotorDiffPos = static_cast<int>((fToPos - fCurPos ) * devConfig[devIndex - 1].fRatio * (32768.f / 360.f));

            LOG_DEBUG("to Angle : %.3f MotorAngle : %d ", fToPos, nMotorCurPos + nToMotorDiffPos);
            m_pMotorXinTuo->CtrlRun(pData, nLen, nMotorCurPos + nToMotorDiffPos,
                                    static_cast<int>(speed * devConfig[devIndex - 1].fRatio) / 6); //控制单位是【转/分钟】期望单位 度/秒
        }
        break;

        case 7:
        case 8:
        {
            int nToMotorDiffPos = static_cast<int>((fToPos - fCurPos) / devConfig[devIndex - 1].fRatio) * 100; //100是单位
            int nRunSpeed = static_cast<int>(speed * 1.0f / devConfig[devIndex - 1].fRatio);
            LOG_DEBUG("%f -> %f pos : %d run : %d", fCurPos, fToPos, nMotorCurPos + nToMotorDiffPos, nRunSpeed);
            // pos 为实际距离
            m_pMotorRMD->CtrlRun(pData, nLen, nMotorCurPos + nToMotorDiffPos, nRunSpeed);
        }
        break;
    }

    return true;
}

void CVrMotorManage::CtrlStop(unsigned int devIndex, unsigned char pData[], unsigned int &nLen)
{
    memset(pData, 0 , 8);
    switch (devIndex) {
    case 5:
    case 6:
        m_pMotorXinTuo->CtrlStop(pData, nLen);
        break;

    case 7:
    case 8:
        m_pMotorRMD->CtrlStop(pData, nLen);
        break;
    }
}

void CVrMotorManage::ReadPID(unsigned int devIndex, unsigned char *pData, unsigned int &nLen)
{
    memset(pData, 0 , 8);
    switch (devIndex) {

    case 7:
    case 8:
        m_pMotorRMD->ReadPID(pData, nLen);
        break;
    }
}

void CVrMotorManage::WritePID(unsigned int devIndex, unsigned char *pData, unsigned int &nLen, const int angleP, const int angleI, const int speedP, const int speedI, const int forceP, const int forceI)
{
    memset(pData, 0 , 8);
    switch (devIndex) {

    case 7:
    case 8:
        m_pMotorRMD->WritePID(pData, nLen, angleP, angleI, speedP, speedI, forceP, forceI);
        break;
    }
}

void CVrMotorManage::ParsePID(unsigned int devIndex, unsigned char *pData, unsigned int nLen, int &angleP, int &angleI, int &speedP, int &speedI, int &forceP, int &forceI)
{
    switch (devIndex) {

    case 7:
    case 8:
        m_pMotorRMD->ParsePID(pData, nLen, angleP, angleI, speedP, speedI, forceP, forceI);
        break;
    }
}

void CVrMotorManage::SaveArgToFlash(unsigned int devIndex, unsigned char* pData, unsigned int &nLen)
{
    memset(pData, 0 , 8);
    nLen = 0;
    switch (devIndex) {
    case 5:
    case 6:
        m_pMotorXinTuo->SaveArgToFlash(pData, nLen);
        break;

    case 7:
    case 8:
        m_pMotorRMD->SaveArgToFlash(pData, nLen);
        break;
    }
}
