#include "VrTimeUtils.h"

CVrTimeUtils::CVrTimeUtils()
{
	m_begin = std::chrono::high_resolution_clock::now();
}


CVrTimeUtils::~CVrTimeUtils()
{
}

void CVrTimeUtils::Update()
{
	m_begin = std::chrono::high_resolution_clock::now();
}

double CVrTimeUtils::GetElapsedSecond()
{
	return GetElapsedTimeInMicroSec() * 0.000001;
}

double CVrTimeUtils::GetElapsedTimeInMilliSec()
{
	return GetElapsedTimeInMicroSec() * 0.001;
}

long long CVrTimeUtils::GetElapsedTimeInMicroSec()
{
	return std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::high_resolution_clock::now() - m_begin).count();
}
