#include "StringUtils.h"

QByteArray CVrStringUtils::HexStringToByteArray(QString HexString)
{
    bool ok;
    QByteArray ret;
    HexString = HexString.trimmed();
    HexString = HexString.simplified();
    QStringList sl = HexString.split(" ");

    foreach (QString s, sl)
    {
        if(!s.isEmpty())
        {
            char c = s.toInt(&ok,16)&0xFF;
            if(ok)
            {
                ret.append(c);
            }
            else
            { }
        }
    }
    return ret;
}
