#include "VrSerialPort.h"
#include "VrLog.h"

#include "VrTimeUtils.h"
#include "StringUtils.h"

CVrSerialPort::CVrSerialPort()
{
    m_serialport = new QSerialPort();
//    connect(m_serialport,SIGNAL(readyRead()),this,SLOT(receive_data()));
}

CVrSerialPort::~CVrSerialPort()
{

}

std::list<std::string> CVrSerialPort::GetDevList()
{
    std::list<std::string> serailList;
    serailList.clear();

    //获得所有可用端口列表
    QList<QSerialPortInfo> serialPortInfoList = QSerialPortInfo::availablePorts();
    if(serialPortInfoList.isEmpty()){
        return serailList;
    }
    QList<QSerialPortInfo>::iterator iter = serialPortInfoList.begin();
    //将所有端口添加到界面的下拉列表中
    while(iter!=serialPortInfoList.end()){
        serailList.push_back(iter->portName().toStdString());
        iter++;
    }
    return serailList;
}

bool CVrSerialPort::OpenDev(std::string serail, int baud)
{
    //判断串口开启状态
    if(m_serialport->isOpen())
    {
        return true;
    }

    m_serialport->setPortName(QString::fromStdString(serail));
    m_serialport->open(QIODevice::ReadWrite);
//        m_serialport->setBaudRate(QSerialPort::Baud115200);
    m_serialport->setBaudRate(baud);
    m_serialport->setDataBits(QSerialPort::Data8);
    m_serialport->setParity(QSerialPort::NoParity);
    m_serialport->setStopBits(QSerialPort::OneStop);
    m_serialport->setFlowControl(QSerialPort::NoFlowControl);

    return m_serialport->isOpen();
}

bool CVrSerialPort::CloseDev()
{
    if(m_serialport->isOpen()){
        m_serialport->clear();
        m_serialport->close();
    }
    return true;
}

bool CVrSerialPort::SendDataAndRecv(const unsigned char *pData, const unsigned int nLen, unsigned char *pRecvData, unsigned int &nRecvLen)
{
    if(!m_serialport->isOpen()) return false;

    int nSendLen = m_serialport->write((char *)pData, nLen);

    bool bRet = false;

    if(nLen != nSendLen) return false;

#if 1
    if(m_serialport->waitForReadyRead(1000))
    {
        QByteArray recvMsg = m_serialport->readAll();
        QString message = recvMsg.toHex();
        nRecvLen = recvMsg.length();
        LOG_DEBUG("wait recv : %s %d", message.toStdString().c_str(), nRecvLen);

        memcpy(pRecvData, recvMsg.data(), nRecvLen);
        bRet = true;
    }
#endif
    return bRet;
}

void CVrSerialPort::receive_data()
{
    QString message = m_serialport->readAll().toHex();
    LOG_DEBUG("recv : %s", message.toStdString().c_str());
}
