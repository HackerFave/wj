#ifndef STRINGUTILS_H
#define STRINGUTILS_H

#include <QByteArray>
#include <QStringList>
#include <QDateTime>

namespace CVrStringUtils
{
    QByteArray HexStringToByteArray(QString HexString);
};

#endif // STRINGUTILS_H
