#pragma once
#include <iostream>
#include <QtSerialPort/QSerialPort>         // 提供访问串口的功能
#include <QtSerialPort/QSerialPortInfo>      // 提供系统中存在的串口信息
#include <list>

class CVrSerialPort : public QObject
{
    Q_OBJECT

public:
    CVrSerialPort();
    virtual ~CVrSerialPort();

public:
    std::list<std::string> GetDevList();

public:
    // 打开串口
    bool OpenDev(std::string serail, int baud);

    // 关闭串口
    bool CloseDev();

    // 发送数据
    bool SendDataAndRecv(const unsigned char* pData, const unsigned int nLen, unsigned char* pRecvData, unsigned int& nRecvLen);

private slots:
    void receive_data();//接收串口数据

private:
    QSerialPort* m_serialport;



};
