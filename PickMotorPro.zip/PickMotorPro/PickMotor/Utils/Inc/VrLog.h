#pragma once

#include <QDebug>

#define LOG_DEBUG qDebug
